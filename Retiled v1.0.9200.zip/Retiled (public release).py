import os
import requests
import feedparser
from flask import Flask, Response, send_from_directory
from datetime import datetime
from urllib.parse import urlparse
from PIL import Image
from io import BytesIO
from urllib.parse import urlparse 
import hashlib
import urllib
import json
import re
import random
import psutil
from bs4 import BeautifulSoup
from requests.exceptions import Timeout, RequestException  # ✅ Add this line
from apscheduler.schedulers.background import BackgroundScheduler
from PIL import UnidentifiedImageError
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry
import time
app = Flask(__name__)

# Configurations
FINNHUB_API_KEY = "also unused"
OPENWEATHERMAP_API_KEY = "unused since theres another one"
RSS_IMAGES_FOLDER = "C:/rss_images/"
TILE_XML_FOLDER = "C:/Tiles/"

# RSS Feeds (american by default)
RSS_FEEDS = {
    "news": "https://rss.app/feeds/BQqhkpPfPxQkn5P5.xml",  # The New York Times - Home Page
    "finance": "https://rss.app/feeds/tLYDXG5I1ROerruG.xml",  # CNBC - Top News & Analysis
    "sports": "https://www.espn.com/espn/rss/news",  # ESPN - Top News
    
}
# Ensure RSS images folder exists
if not os.path.exists(RSS_IMAGES_FOLDER):
    os.makedirs(RSS_IMAGES_FOLDER)  

# Function to download and save RSS images
# Ensure no proxy is used
def download_image(image_url):
    if not image_url:
        return None

    parsed_url = urlparse(image_url)
    filename = os.path.basename(parsed_url.path)
    
    # Ensure the filename has a .jpg extension
    filename = os.path.splitext(filename)[0] + ".jpg"
    save_path = os.path.join(RSS_IMAGES_FOLDER, filename)

    if not os.path.exists(save_path):
        try:
            # Create a new session and bypass proxy
            session = requests.Session()
            session.proxies = {}  # Ensure no proxy is used

            # Send the GET request for the image
            response = session.get(image_url, stream=True, timeout=10)

            if response.status_code == 200:
                # Open the image to check the format and convert if necessary
                image = Image.open(BytesIO(response.content))

                # Convert to RGB if the image is not in a format that can be saved as JPG
                if image.mode != 'RGB':
                    image = image.convert('RGB')

                # Save the image as JPG
                image.save(save_path, "JPEG")
                
                print(f"Image saved as JPG: {save_path}")
                return f"http://127.0.0.1/rss_images/{filename}"

        except Exception as e:
            print(f"Failed to download or convert {image_url}: {e}")
            return None
    else:
        print(f"Image already exists: {save_path}")
        return f"http://127.0.0.1/rss_images/{filename}"
# Route for serving saved images
@app.route('/rss_images/<path:filename>')
def serve_rss_image(filename):
    return send_from_directory(RSS_IMAGES_FOLDER, filename)

# Ensure no proxy is used
def download_image(img_url, name):
    """Download an image and return its local URL for the tile."""
    if not img_url:
        return None

    image_path = os.path.join(RSS_IMAGE_SAVE_PATH, name)
    image_url_path = f"{IMG_HOST}/{name}"

    if os.path.exists(image_path):
        print(f"Image already exists: {image_url_path}")
        return image_url_path

    try:
        # Create a session and bypass the proxy
        session = requests.Session()
        session.proxies = {}  # Ensure no proxy is used
        proxies=None

        # Send the GET request to download the image
        response = session.get(img_url, stream=True)
        if response.status_code == 200:
            # Create directory if it doesn't exist
            os.makedirs(RSS_IMAGE_SAVE_PATH, exist_ok=True)

            # Save the image in chunks
            with open(image_path, "wb") as file:
                for chunk in response.iter_content(1024):
                    file.write(chunk)
            print(f"✅ Downloaded: {image_url_path}")
            return image_url_path
        else:
            print(f"❌ Failed to download {img_url} (HTTP {response.status_code})")
    except Exception as e:
        print(f"⚠️ Error downloading {img_url}: {e}")
    
    # Fallback to a default image if there was an error
    image_name = os.path.basename(urlparse(img_url).path) if img_url else "default.jpg"
    saved_image_url = download_image(img_url, image_name) if img_url else None
    return saved_image_url

def fetch_rss_data(category):
    """Fetch and parse RSS feed entries for a given category, download images."""
    if category not in RSS_FEEDS:
        print(f"Invalid category: {category}")
        return []

    feed_url = RSS_FEEDS[category]
    feed = feedparser.parse(feed_url)

    if not feed.entries:
        return []

    entries = []
    for entry in feed.entries:
        title = entry.get("title", "No title")
        link = entry.get("link", "#")
        description = entry.get("description", "No description")
        image_url = None
        img_src = None
        enclosure_url = None

        # Extract image from media:content, media:thumbnail, or image tag
        if "media_content" in entry:
            image_url = entry.media_content[0]['url']
        elif "media_thumbnail" in entry:
            image_url = entry.media_thumbnail[0]['url']
        elif "image" in entry:
            image_url = entry.image

        # Extract image from <img> tag in content
        if "content" in entry and entry.content:
            soup = BeautifulSoup(entry.content[0].value, "html.parser")
            img_tag = soup.find("img")
            if img_tag and "src" in img_tag.attrs:
                img_src = img_tag["src"]

        # Extract enclosure URL
        if "enclosures" in entry and entry.enclosures:
            enclosure_url = entry.enclosures[0]["url"]

        # Prioritize media_content > media_thumbnail > img src > enclosure
        final_image_url = image_url or img_src or enclosure_url

        # Download image if available, otherwise use default image
        if final_image_url:
            image_filename = download_rss_image(final_image_url)
            local_image_url = f"http://127.0.0.1/rss_images/{image_filename}"
        else:
            local_image_url = f"http://127.0.0.1/rss_images/default.jpg"

        # Append the RSS entry with image and other details
        entries.append({
            "title": title,
            "link": link,
            "description": description,
            "image": local_image_url,
            "img_src": img_src,
            "enclosure": enclosure_url
        })

    return entries


RSS_IMAGES_FOLDER = "C:/rss_images/"  # Your image folder

def download_rss_image(image_url):
    """Download an RSS image and convert non-JPG files to JPG."""
    try:
        # Completely disable proxies in the environment and requests
        os.environ.pop("HTTP_PROXY", None)
        os.environ.pop("HTTPS_PROXY", None)
        os.environ.pop("http_proxy", None)
        os.environ.pop("https_proxy", None)

    # Retry logic for handling temporary failures
        retry_strategy = Retry(
        total=3,
        backoff_factor=1,
        status_forcelist=[500, 502, 503, 504],
        allowed_methods=["HEAD", "GET", "OPTIONS"]
       )
        adapter = HTTPAdapter(max_retries=retry_strategy)

    # Create a session with NO proxies
        session = requests.Session()
        session.mount("http://", adapter)
        session.mount("https://", adapter)
        session.trust_env = False  # Forces requests to ignore system proxy settings

        response = session.get(image_url, stream=True, timeout=5, proxies=None)
        
        if response.status_code == 200:
            file_ext = os.path.splitext(image_url.split("?")[0])[-1].lower()

            # Generate unique filename using SHA256 hash
            file_hash = hashlib.sha256(image_url.encode()).hexdigest()[:15]
            filename = f"{file_hash}{file_ext}"
            file_path = os.path.join(RSS_IMAGES_FOLDER, filename)

            # Save the original image file
            with open(file_path, "wb") as img_file:
                for chunk in response.iter_content(1024):
                    img_file.write(chunk)

            # Convert non-JPG files to JPG
            if file_ext not in [".jpg", ".jpeg"]:
                new_filename = f"{file_hash}.jpg"
                new_file_path = os.path.join(RSS_IMAGES_FOLDER, new_filename)

                try:
                    with Image.open(file_path) as img:
                        img = img.convert("RGB")
                        img.save(new_file_path, "JPEG", quality=85)
                    os.remove(file_path)  # Delete the original non-JPG file
                    return new_filename  # Return the converted JPG filename
                except UnidentifiedImageError:
                    print(f"Failed to convert {file_path} to JPG")

            return filename  # Return the original filename if it's already JPG

    except Exception as e:
        print(f"Failed to download image {image_url}: {e}")

    return "default.jpg"  # Return a default image if there was an error



# Fetch stock market data from Finnhub
def fetch_stock_data():
    """Fetch stock data from Finnhub API without using proxies."""
    stock_symbols = ["AAPL", "MSFT", "TSLA"]
    stock_data = {}

    # Completely disable proxies in the environment and requests
    os.environ.pop("HTTP_PROXY", None)
    os.environ.pop("HTTPS_PROXY", None)
    os.environ.pop("http_proxy", None)
    os.environ.pop("https_proxy", None)

    # Retry logic for handling temporary failures
    retry_strategy = Retry(
        total=3,
        backoff_factor=1,
        status_forcelist=[500, 502, 503, 504],
        allowed_methods=["HEAD", "GET", "OPTIONS"]
    )
    adapter = HTTPAdapter(max_retries=retry_strategy)

    # Create a session with NO proxies
    session = requests.Session()
    session.mount("http://", adapter)
    session.mount("https://", adapter)
    session.trust_env = False  # Forces requests to ignore system proxy settings

    # Explicitly set proxies=None when making requests
    for symbol in stock_symbols:
        url = f"https://finnhub.io/api/v1/quote?symbol={symbol}&token=set_your_own_api_finnhub_key_here"

        try:
            response = session.get(url, proxies={}, timeout=10)  # 🔥 Forces NO proxies
            response.raise_for_status()

            data = response.json()

            stock_data[symbol] = {
                "price": data.get("c", "N/A"),
                "change": data.get("d", "N/A"),
                "percent_change": data.get("dp", "N/A"),
                "timestamp": datetime.utcfromtimestamp(data.get("t", 0)).strftime('%m/%d/%Y %I:%M %p UTC')
            }
        except requests.exceptions.RequestException as e:
            print(f"Error fetching data for {symbol}: {e}")
            stock_data[symbol] = {
                "price": "N/A",
                "change": "N/A",
                "percent_change": "N/A",
                "timestamp": "N/A"
            }

    return stock_data

def fetch_weather_data():
    api_key = "use_your_own_openweathermapapikey"
    city = "set your city name here"

    # Completely disable proxies in the environment
    os.environ.pop("HTTP_PROXY", None)
    os.environ.pop("HTTPS_PROXY", None)
    os.environ.pop("http_proxy", None)
    os.environ.pop("https_proxy", None)

    # Retry logic for handling temporary failures
    retry_strategy = Retry(
        total=3,
        backoff_factor=1,
        status_forcelist=[500, 502, 503, 504],
        allowed_methods=["HEAD", "GET", "OPTIONS"]
    )
    adapter = HTTPAdapter(max_retries=retry_strategy)

    # Create a session with NO proxies
    session = requests.Session()
    session.mount("http://", adapter)
    session.mount("https://", adapter)
    session.trust_env = False  # Forces requests to ignore system proxy settings

    # Fetch current weather data
    url_current = f"https://api.openweathermap.org/data/2.5/weather?q=Copacabana&units=metric&appid={api_key}"
    response = session.get(url_current, proxies={"http": None, "https": None}, timeout=10)
    
    if not response.content:
        return None
    response.encoding = 'utf-8'

    try:
        data = response.json()
        if data.get("cod") != 200:
            return None
        
        temp = round(data["main"]["temp"])
        condition = data["weather"][0]["description"].capitalize()
        icon_code = data["weather"][0]["icon"]
        icon_url = f"http://openweathermap.org/img/wn/{icon_code}.png"
        wind_speed = round(data["wind"]["speed"] * 3.6)  # Convert from m/s to km/h
        humidity = data["main"]["humidity"]

        # Fetch forecast data
        url_forecast = f"https://api.openweathermap.org/data/2.5/forecast?q=Copacabana&units=metric&appid={api_key}"
        forecast_response = session.get(url_forecast, proxies={"http": None, "https": None}, timeout=10)
        forecast_data = forecast_response.json()

        if "list" not in forecast_data:
            return None
        
        tomorrow_data = forecast_data["list"][8]  
        tomorrow_high = round(tomorrow_data["main"]["temp_max"])
        tomorrow_low = round(tomorrow_data["main"]["temp_min"])
        tomorrow_description = tomorrow_data["weather"][0]["description"].capitalize()

        return {
            "current_temp": temp,
            "location": "Copacabana",
            "weather_icon_url": icon_url,
            "weather_condition": condition,
            "today_description": condition,
            "high_temp": round(data["main"]["temp_max"]),
            "low_temp": round(data["main"]["temp_min"]),
            "wind_speed": wind_speed,  
            "humidity": humidity,  
            "tomorrow_high": tomorrow_high,  
            "tomorrow_low": tomorrow_low,  
            "tomorrow_description": tomorrow_description,  
        }

    except Exception as e:
        print(f"Error fetching weather data: {e}")
        return None

@app.route("/WeatherService.svc/LiveTile")
def serve_msn_weather():
    weather_data = fetch_weather_data()
    if not weather_data:
        return "Error fetching weather data", 500
    try:
        with open("c:/Tiles/msn_weather.xml", "r", encoding="utf-8") as file:
            xml_content = file.read()
    except Exception as e:
        return f"Error reading XML file: {str(e)}", 500
    xml_content = xml_content.replace("{current_temp}", str(weather_data["current_temp"]))
    xml_content = xml_content.replace("{location}", weather_data["location"])
    xml_content = xml_content.replace("{weather_icon_url}", weather_data["weather_icon_url"])
    xml_content = xml_content.replace("{weather_condition}", weather_data["weather_condition"])
    xml_content = xml_content.replace("{tomorrow_high}", str(weather_data["tomorrow_high"]))
    xml_content = xml_content.replace("{tomorrow_low}", str(weather_data["tomorrow_low"]))


    return Response(xml_content, mimetype="application/xml")


@app.route("/Market.svc/AppTile")
def serve_financedata():
    """Serve the finance tile with updated stock data."""
    # Fetch stock data from Finnhub
    stock_data = fetch_stock_data()

    # Read the XML template (adjust the path to the XML file)
    try:
        with open("AppTile.xml", "r", encoding="utf-8-sig") as file:
            xml_content = file.read()
    except FileNotFoundError:
        return "Error: XML template not found", 404



    # Replace placeholders in the XML with stock data
    xml_content = xml_content.replace("{AAPL_PRICE}", f"{stock_data['AAPL']['price']}")
    xml_content = xml_content.replace("{AAPL_CHANGE}", f"{stock_data['AAPL']['change']} ({stock_data['AAPL']['percent_change']}%)")
    xml_content = xml_content.replace("{MSFT_PRICE}", f"{stock_data['MSFT']['price']}")
    xml_content = xml_content.replace("{MSFT_CHANGE}", f"{stock_data['MSFT']['change']} ({stock_data['MSFT']['percent_change']}%)")
    xml_content = xml_content.replace("{TSLA_PRICE}", f"{stock_data['TSLA']['price']}")
    xml_content = xml_content.replace("{TSLA_CHANGE}", f"{stock_data['TSLA']['change']} ({stock_data['TSLA']['percent_change']}%)")
    xml_content = xml_content.replace("{LAST_UPDATE}", stock_data["AAPL"]["timestamp"])



    # Return the updated XML with MIME type
    return Response(xml_content, mimetype="application/xml; charset=utf-8")
   



# Route to serve News tile XML files
@app.route("/cgtile/v1/PT-BR/News/Today.xml")
def serve_news_today():
    return serve_tile_for_category("news", "Today.xml")

# Route to serve Finance tile XML file
@app.route("/cgtile/v1/PT-BR/Finance/Today.xml")
def serve_finance_today():
    return serve_tile_for_category("finance", "Today.xml")

# Route to serve Sports tile XML file
@app.route("/cgtile/v1/pt-br/Sports/Today.xml")
def serve_sports_today():
    return serve_tile_for_category("sports", "sportstoday.xml")


def serve_tile_for_category(category, file_name):
    xml_file_path = os.path.join(TILE_XML_FOLDER, file_name)
    if os.path.exists(xml_file_path):
        with open(xml_file_path, "r", encoding="utf-8") as xml_file:
            xml_content = xml_file.read()
            # Fetch RSS data for categories

            if category == "news":
                articles = fetch_rss_data("news")
                if articles:
                    xml_content = xml_content.replace("{article_text}", articles[0]["title"])
                    xml_content = xml_content.replace("{img_url}", articles[0]["image"] if articles[0]["image"] else "")

            elif category == "sports":
                articles = fetch_rss_data("sports")
                if articles:
                    xml_content = xml_content.replace("{article_text}", articles[0]["title"])


            elif category == "finance":
                articles = fetch_rss_data("finance")
                if articles:
                    xml_content = xml_content.replace("{article_text}", articles[0]["title"])
                    xml_content = xml_content.replace("{img_url}", articles[0]["image"] if articles[0]["image"] else "")

        return Response(xml_content, mimetype="application/xml")

    return "Tile not found", 404

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=80, debug=True)
