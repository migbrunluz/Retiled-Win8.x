Retiled v1.0.9200

Patches bing apps for windows 8.0
 DM me on Discord or Reddit lmk if the script errors out or works,i'd be happy to help you

TIP: you can swap rss feeds on the code itself

MOVE THE TILES FOLDER TO THE MAIN C DRIVE

