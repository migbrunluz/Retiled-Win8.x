Retiled v1 - your only source of msn related stuff

DM me on Reddit or Discord if you have any issue or problems with the code or script,i'd be happy to help you

TIP: you can swap rss feeds on the code itself

MOVE THE TILES FOLDER TO THE MAIN C DRIVE

