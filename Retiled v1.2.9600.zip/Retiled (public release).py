import os
import time
import jsonify
import requests
import feedparser
import pyowm
from pyowm.owm import OWM
from pyowm.utils.config import get_default_config
import yfinance as yf
from flask import Flask, Response, send_from_directory, send_file
from datetime import datetime
from urllib.parse import urlparse
from PIL import Image
from io import BytesIO
import xml.etree.ElementTree as ET  
from urllib.parse import urlparse 
import hashlib
import urllib
import json
import re
import random
import psutil
from flask import Flask, jsonify
from requests.exceptions import Timeout, RequestException  # ✅ Add this line
from apscheduler.schedulers.background import BackgroundScheduler
from PIL import UnidentifiedImageError
 
app = Flask(__name__)

# Configurations
RSS_IMAGES_FOLDER = "C:/rss_images/"
TILE_XML_FOLDER = "C:/Tiles/"

# RSS Feeds (american by default)
RSS_FEEDS = {
    "news": "https://rss.nytimes.com/services/xml/rss/nyt/HomePage.xml",  # The New York Times - Home Page
    "finance": "https://www.cnbc.com/id/10000664/device/rss/rss.html",  # CNBC - Top News & Analysis
    "sports": "https://www.espn.com/espn/rss/news",  # ESPN - Top News
    "health": "https://www.npr.org/rss/rss.php?id=1128",  # NPR - Health News
    "travel": "https://feeds.nationalgeographic.com/ng/News/Travel",  # National Geographic - Travel
    "food": "https://www.foodbusinessnews.net/rss/2",  # Food Business news
    "fitness": "https://www.menshealth.com/rss/all.xml",  # Men's Health - Fitness
    "games": "https://www.polygon.com/rss/index.xml",  # Polygon - Gaming News
    "video": "https://www.theverge.com/rss/index.xml",  # The Verge - Technology and more
}
# Ensure RSS images folder exists
if not os.path.exists(RSS_IMAGES_FOLDER):
    os.makedirs(RSS_IMAGES_FOLDER)  

# Function to download and save RSS images
def download_image(image_url):
    if not image_url:
        return None

    parsed_url = urlparse(image_url)
    filename = os.path.basename(parsed_url.path)
    
    # Ensure the filename has a .jpg extension
    filename = os.path.splitext(filename)[0] + ".jpg"
    save_path = os.path.join(RSS_IMAGES_FOLDER, filename)

    if not os.path.exists(save_path):
        try:
            response = requests.get(image_url, stream=True)
            if response.status_code == 200:
                # Open the image to check the format and convert if necessary
                image = Image.open(BytesIO(response.content))

                # Convert to RGB if the image is not in a format that can be saved as JPG
                if image.mode != 'RGB':
                    image = image.convert('RGB')

                # Save the image as JPG
                image.save(save_path, "JPEG")
                
                print(f"Image saved as JPG: {save_path}")
                return f"http://127.0.0.1/rss_images/{filename}"

        except Exception as e:
            print(f"Failed to download or convert {image_url}: {e}")
            return None

    return f"http://127.0.0.1/rss_images/{filename}"
# Route for serving saved images
@app.route('/rss_images/<path:filename>')
def serve_rss_image(filename):
    return send_from_directory(RSS_IMAGES_FOLDER, filename)

def download_image(img_url, name):
    """Download an image and return its local URL for the tile."""
    if not img_url:
        return None

    image_path = os.path.join(RSS_IMAGE_SAVE_PATH, name)
    image_url_path = f"{IMG_HOST}/{name}"

    if os.path.exists(image_path):
        print(f"Image already exists: {image_url_path}")
        return image_url_path

    try:
        response = requests.get(img_url, stream=True,)
        if response.status_code == 200:
            os.makedirs(RSS_IMAGE_SAVE_PATH, exist_ok=True)
            with open(image_path, "wb") as file:
                for chunk in response.iter_content(1024):
                    file.write(chunk)
            print(f"✅ Downloaded: {image_url_path}")
            return image_url_path
        else:
            print(f"❌ Failed to download {img_url} (HTTP {response.status_code})")
    except Exception as e:
        print(f"⚠️ Error downloading {img_url}: {e}")
    image_name = os.path.basename(urlparse(image_url).path) if image_url else "default.jpg"
    saved_image_url = download_image(image_url, image_name) if image_url else None



def fetch_rss_data(category):
    """Fetch and parse RSS feed entries for a given category, download images."""
    if category not in RSS_FEEDS:
        print(f"Invalid category: {category}")
        return []

    feed_url = RSS_FEEDS[category]
    feed = feedparser.parse(feed_url)

    if not feed.entries:
        return []

    entries = []
    for entry in feed.entries:
        title = entry.get("title", "No title")
        link = entry.get("link", "#")
        description = entry.get("description", "No description")
        image_url = None
        img_src = None
        enclosure_url = None

        # Extract image from media:content, media:thumbnail, or image tag
        if "media_content" in entry:
            image_url = entry.media_content[0]['url']
        elif "media_thumbnail" in entry:
            image_url = entry.media_thumbnail[0]['url']
        elif "image" in entry:
            image_url = entry.image

        # Extract image from <img> tag in content
        if "content" in entry and entry.content:
            soup = BeautifulSoup(entry.content[0].value, "html.parser")
            img_tag = soup.find("img")
            if img_tag and "src" in img_tag.attrs:
                img_src = img_tag["src"]

        # Extract enclosure URL
        if "enclosures" in entry and entry.enclosures:
            enclosure_url = entry.enclosures[0]["url"]

        # Prioritize media_content > media_thumbnail > img src > enclosure
        final_image_url = image_url or img_src or enclosure_url

        if final_image_url:
            image_filename = download_rss_image(final_image_url)
            local_image_url = f"http://127.0.0.1/rss_images/{image_filename}"
        else:
            local_image_url = "http://127.0.0.1/rss_images/default.jpg"

        entries.append({
            "title": title,
            "link": link,
            "description": description,
            "image": local_image_url,
            "img_src": img_src,
            "enclosure": enclosure_url
        })

    return entries



RSS_IMAGES_FOLDER = "C:/rss_images/"  # Your image folder

def download_rss_image(image_url):
    """Download an RSS image and convert non-JPG files to JPG."""
    try:
        response = requests.get(image_url, stream=True, timeout=5)
        if response.status_code == 200:
            file_ext = os.path.splitext(image_url.split("?")[0])[-1].lower()

            # Generate unique filename
            file_hash = hashlib.sha256(image_url.encode()).hexdigest()[:15]
            filename = f"{file_hash}{file_ext}"
            file_path = os.path.join(RSS_IMAGES_FOLDER, filename)

            # Save original file
            with open(file_path, "wb") as img_file:
                for chunk in response.iter_content(1024):
                    img_file.write(chunk)

            # Convert non-JPG files to JPG
            if file_ext not in [".jpg", ".jpeg"]:
                new_filename = f"{file_hash}.jpg"
                new_file_path = os.path.join(RSS_IMAGES_FOLDER, new_filename)

                try:
                    with Image.open(file_path) as img:
                        img = img.convert("RGB")
                        img.save(new_file_path, "JPEG", quality=85)
                    os.remove(file_path)  # Delete original
                    return new_filename  # Return converted JPG filename
                except UnidentifiedImageError:
                    print(f"Failed to convert {file_path} to JPG")

            return filename  # Return original if it's already JPG

    except Exception as e:
        print(f"Failed to download image {image_url}: {e}")

    return "default.jpg"



def fetch_stock_data():
    tickers = {
        "AAPL": "AAPL",   # Apple
        "MSFT": "MSFT",   # Microsoft
        "TSLA": "TSLA",   # Tesla
        "IBXX": "IBXX.SA", # IBXX (Brazil)
        "IBOV": "^BVSP",   # IBOVESPA Index
        "PETR3": "PETR3.SA" # Petrobras
    }

    stock_data = {}

    for name, ticker in tickers.items():
        stock = yf.Ticker(ticker)

        try:
            data = stock.history(period="1d")
            if data is not None and not data.empty:
                last_close = data["Close"].iloc[-1]
                change = last_close - data["Open"].iloc[-1]
                percent_change = (change / data["Open"].iloc[-1]) * 100
                timestamp = data.index[-1].strftime("%Y-%m-%d %H:%M:%S")

                change_symbol = "▲" if change >= 0 else "▼"

                stock_data[name] = {
                    "price": f"{last_close:.2f}",
                    "change": f"{change_symbol} {abs(change):.2f}",
                    "percent_change": f"{percent_change:.2f}",
                    "timestamp": timestamp
                }
            else:
                stock_data[name] = {"price": "N/A", "change": "N/A", "percent_change": "N/A", "timestamp": "N/A"}

        except Exception as e:
            print(f"Error fetching data for {ticker}: {e}")
            stock_data[name] = {"price": "Error", "change": "Error", "percent_change": "Error", "timestamp": "Error"}

    return stock_data

@app.route("/Market.svc/AppTileV2")
def serve_financedata():
    """Serve the finance tile with updated stock data."""
    stock_data = fetch_stock_data()

    try:
        with open("AppTileV2.xml", "r", encoding="utf-8-sig") as file:
            xml_content = file.read()
    except FileNotFoundError:
        return "Error: XML template not found", 404

    # Replace placeholders safely
    for ticker in ["AAPL", "MSFT", "TSLA"]:
        xml_content = xml_content.replace(f"{{{ticker}_PRICE}}", stock_data.get(ticker, {}).get("price", "N/A"))
        xml_content = xml_content.replace(f"{{{ticker}_CHANGE}}", f"{stock_data.get(ticker, {}).get('change', 'N/A')} ({stock_data.get(ticker, {}).get('percent_change', 'N/A')}%)")

    # Set last update timestamp
    last_update = stock_data.get("AAPL", {}).get("timestamp", "N/A")
    xml_content = xml_content.replace("{LAST_UPDATE}", last_update)

    return Response(xml_content, mimetype="application/xml; charset=utf-8")

# yummy live tiles
MSN_WEATHER_IMAGE_MAP = {
    "01d": "https://i.ibb.co/bgPy3r2D/9c.jpg",
    "01n": "https://i.ibb.co/xSPksFPh/31b.jpg",
    "02d": "https://i.ibb.co/x8R3T3gp/26.jpg",
    "02n": "https://i.ibb.co/d4BKRfcR/29b.jpg",
    "03d": "https://i.ibb.co/d4BKRfcR/29b.jpg",
    "03n": "https://i.ibb.co/xSPksFPh/31b.jpg",
    "04d": "https://i.ibb.co/j9H3ZdSB/29.jpg",
    "04n": "https://i.ibb.co/d4BKRfcR/29b.jpg",
    "09d": "https://i.ibb.co/FqD8cjBW/11b.jpg",
    "09n": "https://i.ibb.co/BVJ5vVr8/40.jpg",
    "10d": "https://i.ibb.co/BVJ5vVr8/40.jpg",
    "10n": "https://i.ibb.co/BVJ5vVr8/40.jpg",
    "11d": "https://i.ibb.co/53bTqvm/11b.jpg",
    "11n": "https://i.ibb.co/53bTqvm/11b.jpg",
    "50d": "https://i.ibb.co/KjcWRTjp/44.jpg",
    "50n": "https://i.ibb.co/KjwYgWVZ/20b.jpg",
    "13d": "https://i.ibb.co/pjpQZW3c/5-1.jpg",
    "13n": "https://i.ibb.co/67WkyCQ9/7.jpg",
}



# AccuWeather background image mapping
ACCUWEATHER_IMAGE_MAP = {
    "01d": "http://vortex.accuweather.com/adc2010/hostedpages/w8api/bg310x310/01_02.jpg",
    "01n": "http://vortex.accuweather.com/adc2010/hostedpages/w8api/bg310x310/33.jpg",
    "04n": "http://vortex.accuweather.com/adc2010/hostedpages/w8api/bg310x310/06_07_08.jpg",
    "04d": "http://vortext.accuweather.com/adc2010/hostedpages/w8api/bg310x130/03_04_05.jpg",
    "02d": "https://vortex.accuweather.com/adc2010/hostedpages/w8api/bg310x310/03_04_05.jpg",
    "02n": "http//vortex.accuweather.com/adc2010/hostedpages/w8api/bg310x310/38.jpg",
    "03d": "http://vortex.accuweather.com/adc2010/hostedpages/w8api/bg310x310/03_04_05.jpg",
    "03n": "http://vortex.accuweather.com/adc2010/hostedpages/w8api/bg310x310/30_31_32_34_35_36_37.jpg",
    "09d": "http://vortex.accuweather.com/adc2010/hostedpages/w8api/bg310x310/12_13_39_40.jpg",
    "09n": "http://vortex.accuweather.com/adc2010/hostedpages/w8api/bg310x310/24_25_26.jpg",
    "10d": "http://vortex.accuweather.com/adc2010/hostedpages/w8api/bg310x310/14.jpg",
    "10n": "http://vortex.accuweather.com/adc2010/hostedpages/w8api/bg310x310/18.jpg",
    "11d": "http://vortex.accuweather.com/adc2010/hostedpages/w8api/bg310x310/15_41_42.jpg",
    "11n": "http://vortex.accuweather.com/adc2010/hostedpages/w8api/bg310x310/24_25_26.JPG",
    "13d": "http://vortex.accuweather.com/adc2010/hostedpages/w8api/bg310x310/19_43.jpg",
    "13n": "http://vortex.accuweather.com/adc2010/hostedpages/w8api/bg310x310/29.jpg",
    "50d": "http://vortex.accuweather.com/adc2010/hostedpages/w8api/bg310x310/31.jpg",
    "50n": "http://vortex.accuweather.com/adc2010/hostedpages/w8api/bg310x310/11.jpg",
    
}

def fetch_weather_data():
    api_key = "{your_api_key}"
    city = "Rio de Janeiro,BR" # Replace it with your own location

    # Configure OWM with American language
    config_dict = get_default_config()
    config_dict['language'] = 'en'  # Set language to English
    owm = OWM(api_key, config_dict)
    mgr = owm.weather_manager()

    try:
        # Get current weather
        observation = mgr.weather_at_place(city)
        weather = observation.weather

        temp = round(weather.temperature('celsius')["temp"])
        temp_max = round(weather.temperature('celsius')["temp_max"])
        temp_min = round(weather.temperature('celsius')["temp_min"])
        condition = weather.detailed_status.capitalize()
        icon_code = weather.weather_icon_name
        icon_url = f"http://openweathermap.org/img/wn/{icon_code}@2x.png"
        wind_speed = round(weather.wind()["speed"] * 3.6)  # Convert from m/s to km/h
        humidity = weather.humidity

        # Get forecast data
        forecast = mgr.forecast_at_place(city, '3h')  # 3-hourly forecast
        forecast_list = forecast.forecast.weathers

        # Find tomorrow's forecast (approx 24h later)
        if len(forecast_list) >= 8:
            tomorrow_weather = forecast_list[8]  # 8th item ~24h later
            tomorrow_high = round(tomorrow_weather.temperature('celsius')["temp_max"])
            tomorrow_low = round(tomorrow_weather.temperature('celsius')["temp_min"])
            tomorrow_description = tomorrow_weather.detailed_status.capitalize()
        else:
            tomorrow_high = temp_max
            tomorrow_low = temp_min
            tomorrow_description = condition

        return {
            "current_temp": temp,
            "location": "Rio de Janeiro",
            "weather_icon_url": icon_url,
            "weather_condition": condition,
            "today_description": condition,
            "high_temp": temp_max,
            "low_temp": temp_min,
            "wind_speed": wind_speed,
            "humidity": humidity,
            "tomorrow_high": tomorrow_high,
            "tomorrow_low": tomorrow_low,
            "tomorrow_description": tomorrow_description,
            "msn_weather_large": MSN_WEATHER_IMAGE_MAP.get(icon_code, "default_image_url.jpg"),
            "accuweather_large": ACCUWEATHER_IMAGE_MAP.get(icon_code, "http://vortex.accuweather.com/adc2010/hostedpages/w8api/bg310x310/default.jpg"),
        }

    except Exception as e:
        print(f"Error fetching weather data: {e}")
        return None

    
# Go to the accuweather for windows 8 app and check if your locations set,then search up {your location } accuweather and copy the numbers and location and replace it
def serve_actual_weather():
    # Fetch weather data
    weather_data = fetch_weather_data()

    if not weather_data:
        return "Error fetching weather data", 500  # Return a 500 error if the data fetching fails

    # Load the XML template
    try:
        with open("c:/Tiles/weather_main.xml", "r", encoding="utf-8") as file:
            xml_content = file.read()
    except Exception as e:
        return f"Error reading XML file: {str(e)}", 500

    # Replace placeholders with actual weather data
    xml_content = xml_content.replace("{current_temp}", str(weather_data["current_temp"]))
    xml_content = xml_content.replace("{location}", weather_data["location"])
    xml_content = xml_content.replace("{weather_icon_url}", weather_data["weather_icon_url"])
    xml_content = xml_content.replace("{weather_condition}", weather_data["weather_condition"])
    xml_content = xml_content.replace("{high_temp}", str(weather_data["high_temp"]))
    xml_content = xml_content.replace("{low_temp}", str(weather_data["low_temp"]))
    xml_content = xml_content.replace("{today_description}", weather_data["today_description"])
    xml_content = xml_content.replace("{tomorrow_high}", str(weather_data["tomorrow_high"]))
    xml_content = xml_content.replace("{tomorrow_low}", str(weather_data["tomorrow_low"]))
    xml_content = xml_content.replace("{tomorrow_description}", weather_data["tomorrow_description"])
    xml_content = xml_content.replace("{accuweather_large}", weather_data["accuweather_large"])  # ✅ Fix

    return Response(xml_content, mimetype="application/xml")    

# Placeholder to add text for the 2nd AccuWeather live tile to replace {title}
text = [
    "Retiled does what Microwont",
    
]   

# Route for serving the Info tile replace location id and city name with your own
@app.route("/w8api/livetile/forecast/2/en-us/location_id/cityname/True/WorldSat/CSAM")
def serve_weather_secondary():
    # Load the XML template
    try:
        with open("c:/Tiles/weather_info.xml", "r", encoding="utf-8") as file:
            xml_content = file.read()
    except Exception as e:
        return f"Error reading XML file: {str(e)}", 500

    # Whatever you can put here
    random_text = random.choice(text)
    xml_content = xml_content.replace("{title}", random_text)

    # Fetch weather data
    weather_data = fetch_weather_data()
    if not weather_data:
        return "Error fetching weather data", 500

    # Replace the placeholder with the actual AccuWeather background image
    xml_content = xml_content.replace("{accuweather_large}", weather_data["accuweather_large"])

    # Return the modified XML content with proper content type
    return Response(xml_content, mimetype="application/xml")

# same goes to this (Replace the location name inside weather_radar.xml with your own,today description is not affected)
@app.route("/w8api/livetile/forecast/3/en-us/2730001/Fluminense/True/WorldSat/CSAM")
def serve_weather_third():
     weather_data = fetch_weather_data()

     if not weather_data:
        return "Error fetching weather data", 500  # Return a 500 error if the data fetching fails
    
    # Load the XML template
     try:
        with open("c:/Tiles/weather_radar.xml", "r", encoding="utf-8") as file:
            xml_content = file.read()
     except Exception as e:
        return f"Error reading XML file: {str(e)}", 500
    

    # Replace it with your own city name inside the weather_radar.xml file
     xml_content = xml_content.replace("{today_description}", weather_data["today_description"])
     xml_content = xml_content.replace("{location}", weather_data["location"])
    

    # Check if xml_content is properly populated
     if not xml_content:
         return "Error generating XML content", 500

    # Return the modified XML content with proper response and content type
     return Response(xml_content, mimetype="application/xml")

# MSN WEATHER: uses pyowm for the apis  
@app.route("/appex/DesktopTile/LiveTileV2")
def serve_msn_weather():
    weather_data = fetch_weather_data()
    if not weather_data:
        return "Error fetching weather data", 500
    try:
        with open("c:/Tiles/msn_weather.xml", "r", encoding="utf-8") as file:
            xml_content = file.read()
    except Exception as e:
        return f"Error reading XML file: {str(e)}", 500
    xml_content = xml_content.replace("{current_temp}", str(weather_data["current_temp"]))
    xml_content = xml_content.replace("{location}", weather_data["location"])
    xml_content = xml_content.replace("{weather_icon_url}", weather_data["weather_icon_url"])
    xml_content = xml_content.replace("{weather_condition}", weather_data["weather_condition"])
    xml_content = xml_content.replace("{high_temp}", str(weather_data["high_temp"]))
    xml_content = xml_content.replace("{low_temp}", str(weather_data["low_temp"]))
    xml_content = xml_content.replace("{msn_weather_large}", weather_data["msn_weather_large"])
    xml_content = xml_content.replace("{today_description}", weather_data["today_description"])
    xml_content = xml_content.replace("{tomorrow_high}", str(weather_data["tomorrow_high"]))
    xml_content = xml_content.replace("{tomorrow_low}", str(weather_data["tomorrow_low"]))
    xml_content = xml_content.replace("{tomorrow_description}", weather_data["tomorrow_description"]) 


    return Response(xml_content, mimetype="application/xml")

# Route to serve News tile XML files
@app.route("/cgtile/v1/EN-US/News/Today.xml")
def serve_news_today():
    return serve_tile_for_category("news", "Today.xml")

@app.route("/cgtile/v1/EN-US/News/today/2.xml")
def serve_news_2():
    return serve_tile_for_category("news", "2.xml")

@app.route("/cgtile/v1/EN-US/News/today/3.xml")
def serve_news_3():
    return serve_tile_for_category("news", "3.xml")

@app.route("/cgtile/v1/EN-US/News/today/4.xml")
def serve_news_4():
    return serve_tile_for_category("news", "4.xml")

# Route to serve Finance tile XML file
@app.route("/cgtile/v1/en-us/Finance/Today.xml")
def serve_finance_today():
    return serve_tile_for_category("finance", "Today.xml")

# Route to serve Sports tile XML file
@app.route("/cgtile/v1/en-US/Sports/Today.xml")
def serve_sports_today():
    return serve_tile_for_category("sports", "Today.xml")

# Route to serve HealthAndFitness tile XML file
@app.route("/cgtile/v1/en-us/HealthAndFitness/Home.xml")
def serve_health_and_fitness():
    return serve_tile_for_category("health", "Home.xml")
# Route to serve Games tile XML file
@app.route("/en-us/x8/feeds/1.1/Tile-Games")
def serve_games():
    return serve_tile_for_category("games", "Tile-Games.xml")

# Route to serve bing travel
@app.route("/api/livetile.xml")
def serve_travel(): 
    return serve_tile_for_category("travel", "livetile.xml")

# Route to serve Finance tile XML file
@app.route("/en-US/video/feeds/1.2/videolivetile")
def serve_video():
    return serve_tile_for_category("video", "videolivetile.xml")
             

@app.route("/HnFService.svc/GetLiveTileMetaData") 
def serve_fitness():
    return serve_tile_for_category("fitness", "GetLiveTileMetaData.xml")

@app.route("/api/feed/") 
def serve_food():
    return serve_tile_for_category("food", "feed.xml")


def serve_tile_for_category(category, file_name):
    xml_file_path = os.path.join(TILE_XML_FOLDER, file_name)
    if os.path.exists(xml_file_path):
        with open(xml_file_path, "r", encoding="utf-8") as xml_file:
            xml_content = xml_file.read()
            # Fetch RSS data for categories

            if category == "news":
                articles = fetch_rss_data("news")
                if articles:
                    xml_content = xml_content.replace("{article_text}", articles[0]["title"])
                    xml_content = xml_content.replace("{article_text2}", articles[1]["title"] if len(articles) > 1 else "")
                    xml_content = xml_content.replace("{article_text3}", articles[2]["title"] if len(articles) > 2 else "")
                    xml_content = xml_content.replace("{article_text4}", articles[3]["title"] if len(articles) > 2 else "")
                    xml_content = xml_content.replace("{article_text5}", articles[4]["title"] if len(articles) > 2 else "")
                    xml_content = xml_content.replace("{article_text6}", articles[5]["title"] if len(articles) > 2 else "")
                    xml_content = xml_content.replace("{article_text7}", articles[6]["title"] if len(articles) > 2 else "")
                    xml_content = xml_content.replace("{article_text8}", articles[7]["title"] if len(articles) > 2 else "")
                    xml_content = xml_content.replace("{article_text9}", articles[8]["title"] if len(articles) > 2 else "")
                    xml_content = xml_content.replace("{article_text10}", articles[9]["title"] if len(articles) > 2 else "")
                    xml_content = xml_content.replace("{img_url}", articles[0]["image"] if articles[0]["image"] else "")
                    xml_content = xml_content.replace("{img_url2}", articles[3]["image"] if articles[0]["image"] else "")

            elif category == "sports":
                articles = fetch_rss_data("sports")
                if articles:
                    xml_content = xml_content.replace("{article_text}", articles[0]["title"])
                    xml_content = xml_content.replace("{img_url}", articles[0]["image"] if articles[0]["image"] else "")

            elif category == "health":
                articles = fetch_rss_data("health")
                if articles:
                    xml_content = xml_content.replace("{text}", articles[0]["title"])
                    xml_content = xml_content.replace("{health_img}", articles[0]["image"] if articles[0]["image"] else "")

            elif category == "food":
                articles = fetch_rss_data("food")
                if articles:
                    xml_content = xml_content.replace("{food_text}", articles[0]["title"])
                    xml_content = xml_content.replace("{img_url}", articles[0]["image"] if articles[0]["image"] else "")

            elif category == "travel":
                articles = fetch_rss_data("travel")
                if articles:
                    xml_content = xml_content.replace("{article_text}", articles[0]["title"])
                    xml_content = xml_content.replace("{img_url}", articles[0]["image"] if articles[0]["image"] else "")

            elif category == "fitness":
                articles = fetch_rss_data("fitness")
                if articles:
                    xml_content = xml_content.replace("{headline}", articles[0]["title"])
                    xml_content = xml_content.replace("{img_url}", articles[0]["image"] if articles[0]["image"] else "")

            elif category == "games":
                articles = fetch_rss_data("games")
                if articles:
                    xml_content = xml_content.replace("{game_title}", articles[0]["title"])
                    xml_content = xml_content.replace("{game_img}", articles[0]["image"] if articles[0]["image"] else "")

            elif category == "video":
                articles = fetch_rss_data("video")
                if articles:
                    xml_content = xml_content.replace("{movie_name}", articles[0]["title"])
                    xml_content = xml_content.replace("{img_url}", articles[0]["image"] if articles[0]["image"] else "")


            elif category == "finance":
                articles = fetch_rss_data("finance")
                if articles:
                    xml_content = xml_content.replace("{article_text}", articles[0]["title"])
                    xml_content = xml_content.replace("{img_url}", articles[0]["image"] if articles[0]["image"] else "")

        return Response(xml_content, mimetype="application/xml")

    return "Tile not found", 404


# Get the directory where the script is located
BASE_DIR = os.path.dirname(os.path.abspath(__file__))

# Function to serve XML from the script's folder
def serve_xml_for_category(category, filename):
    file_path = os.path.join(BASE_DIR, category, filename)  # Use script directory
    try:
        tree = ET.parse(file_path)  # Parse the XML file
        root = tree.getroot()  # Get the root element of the XML
        xml_str = ET.tostring(root, encoding='utf-8', method='xml')  # Convert to XML string
        return Response(xml_str, content_type='application/xml')  # Return XML response
    except FileNotFoundError:
        return Response(f"<error>File not found: {file_path}</error>", content_type='application/xml'), 404
    except ET.ParseError:  # Catch parse errors correctly
        return Response("<error>Invalid XML format</error>", content_type='application/xml'), 500

# Routes for Xbox game feeds
@app.route("/pt-br/X8/Feeds/1.1/Spotlight-Games")
def serve_spot_games():
    return serve_xml_for_category("games", "Spotlight-Games.xml")

@app.route("/pt-br/X8/Feeds/1.1/Featured-PCGames")
def serve_pc_games():
    return serve_xml_for_category("games", "Featured-PCGames.xml")

@app.route("/pt-br/X8/Feeds/1.1/Featured-XboxGames")
def serve_featured_xboxgames():
    return serve_xml_for_category("games", "Featured-XboxGames.xml")


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=80, debug=True)
