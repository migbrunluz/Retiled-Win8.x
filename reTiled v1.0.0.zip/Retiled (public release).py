import os
import requests
import feedparser
from flask import Flask, Response, send_from_directory
from datetime import datetime
from urllib.parse import urlparse
from PIL import Image
from io import BytesIO
from urllib.parse import urlparse 
import hashlib
import urllib
import json
import re
import random
import psutil
from requests.exceptions import Timeout, RequestException  # ✅ Add this line
from apscheduler.schedulers.background import BackgroundScheduler
from PIL import UnidentifiedImageError
import time
app = Flask(__name__)

# Configurations
FINNHUB_API_KEY = "also unused"
OPENWEATHERMAP_API_KEY = "unused since theres another one"
RSS_IMAGES_FOLDER = "C:/rss_images/"
TILE_XML_FOLDER = "C:/Tiles/"

# RSS Feeds (american by default)
RSS_FEEDS = {
    "news": "https://rss.nytimes.com/services/xml/rss/nyt/HomePage.xml",  # The New York Times - Home Page
    "finance": "https://www.cnbc.com/id/10000664/device/rss/rss.html",  # CNBC - Top News & Analysis
    "sports": "https://www.espn.com/espn/rss/news",  # ESPN - Top News
    "health": "https://www.npr.org/rss/rss.php?id=1128",  # NPR - Health News
    "travel": "https://feeds.nationalgeographic.com/ng/News/Travel",  # National Geographic - Travel
    "food": "https://www.foodbusinessnews.net/rss/2",  # Food Business news
    "fitness": "https://www.menshealth.com/rss/all.xml",  # Men's Health - Fitness
    "games": "https://www.polygon.com/rss/index.xml",  # Polygon - Gaming News
    "video": "https://www.theverge.com/rss/index.xml",  # The Verge - Technology and more
}
# Ensure RSS images folder exists
if not os.path.exists(RSS_IMAGES_FOLDER):
    os.makedirs(RSS_IMAGES_FOLDER)  

# Function to download and save RSS images
def download_image(image_url):
    if not image_url:
        return None

    parsed_url = urlparse(image_url)
    filename = os.path.basename(parsed_url.path)
    
    # Ensure the filename has a .jpg extension
    filename = os.path.splitext(filename)[0] + ".jpg"
    save_path = os.path.join(RSS_IMAGES_FOLDER, filename)

    if not os.path.exists(save_path):
        try:
            response = requests.get(image_url, stream=True)
            if response.status_code == 200:
                # Open the image to check the format and convert if necessary
                image = Image.open(BytesIO(response.content))

                # Convert to RGB if the image is not in a format that can be saved as JPG
                if image.mode != 'RGB':
                    image = image.convert('RGB')

                # Save the image as JPG
                image.save(save_path, "JPEG")
                
                print(f"Image saved as JPG: {save_path}")
                return f"http://127.0.0.1/rss_images/{filename}"

        except Exception as e:
            print(f"Failed to download or convert {image_url}: {e}")
            return None

    return f"http://127.0.0.1/rss_images/{filename}"
# Route for serving saved images
@app.route('/rss_images/<path:filename>')
def serve_rss_image(filename):
    return send_from_directory(RSS_IMAGES_FOLDER, filename)

def download_image(img_url, name):
    """Download an image and return its local URL for the tile."""
    if not img_url:
        return None

    image_path = os.path.join(RSS_IMAGE_SAVE_PATH, name)
    image_url_path = f"{IMG_HOST}/{name}"

    if os.path.exists(image_path):
        print(f"Image already exists: {image_url_path}")
        return image_url_path

    try:
        response = requests.get(img_url, stream=True,)
        if response.status_code == 200:
            os.makedirs(RSS_IMAGE_SAVE_PATH, exist_ok=True)
            with open(image_path, "wb") as file:
                for chunk in response.iter_content(1024):
                    file.write(chunk)
            print(f"✅ Downloaded: {image_url_path}")
            return image_url_path
        else:
            print(f"❌ Failed to download {img_url} (HTTP {response.status_code})")
    except Exception as e:
        print(f"⚠️ Error downloading {img_url}: {e}")
    image_name = os.path.basename(urlparse(image_url).path) if image_url else "default.jpg"
    saved_image_url = download_image(image_url, image_name) if image_url else None



def fetch_rss_data(category):
    """Fetch and parse RSS feed entries for a given category, download images."""
    if category not in RSS_FEEDS:
        print(f"Invalid category: {category}")
        return []

    feed_url = RSS_FEEDS[category]
    feed = feedparser.parse(feed_url)

    if not feed.entries:
        return []

    entries = []
    for entry in feed.entries:
        title = entry.get("title", "No title")
        link = entry.get("link", "#")
        description = entry.get("description", "No description")
        image_url = None
        img_src = None
        enclosure_url = None

        # Extract image from media:content, media:thumbnail, or image tag
        if "media_content" in entry:
            image_url = entry.media_content[0]['url']
        elif "media_thumbnail" in entry:
            image_url = entry.media_thumbnail[0]['url']
        elif "image" in entry:
            image_url = entry.image

        # Extract image from <img> tag in content
        if "content" in entry and entry.content:
            soup = BeautifulSoup(entry.content[0].value, "html.parser")
            img_tag = soup.find("img")
            if img_tag and "src" in img_tag.attrs:
                img_src = img_tag["src"]

        # Extract enclosure URL
        if "enclosures" in entry and entry.enclosures:
            enclosure_url = entry.enclosures[0]["url"]

        # Prioritize media_content > media_thumbnail > img src > enclosure
        final_image_url = image_url or img_src or enclosure_url

        if final_image_url:
            image_filename = download_rss_image(final_image_url)
            local_image_url = f"http://127.0.0.1/rss_images/{image_filename}"
        else:
            local_image_url = "http://127.0.0.1/rss_images/default.jpg"

        entries.append({
            "title": title,
            "link": link,
            "description": description,
            "image": local_image_url,
            "img_src": img_src,
            "enclosure": enclosure_url
        })

    return entries



RSS_IMAGES_FOLDER = "C:/rss_images/"  # Your image folder

def download_rss_image(image_url):
    """Download an RSS image and convert non-JPG files to JPG."""
    try:
        response = requests.get(image_url, stream=True, timeout=5)
        if response.status_code == 200:
            file_ext = os.path.splitext(image_url.split("?")[0])[-1].lower()

            # Generate unique filename
            file_hash = hashlib.sha256(image_url.encode()).hexdigest()[:15]
            filename = f"{file_hash}{file_ext}"
            file_path = os.path.join(RSS_IMAGES_FOLDER, filename)

            # Save original file
            with open(file_path, "wb") as img_file:
                for chunk in response.iter_content(1024):
                    img_file.write(chunk)

            # Convert non-JPG files to JPG
            if file_ext not in [".jpg", ".jpeg"]:
                new_filename = f"{file_hash}.jpg"
                new_file_path = os.path.join(RSS_IMAGES_FOLDER, new_filename)

                try:
                    with Image.open(file_path) as img:
                        img = img.convert("RGB")
                        img.save(new_file_path, "JPEG", quality=85)
                    os.remove(file_path)  # Delete original
                    return new_filename  # Return converted JPG filename
                except UnidentifiedImageError:
                    print(f"Failed to convert {file_path} to JPG")

            return filename  # Return original if it's already JPG

    except Exception as e:
        print(f"Failed to download image {image_url}: {e}")

    return "default.jpg"



# Fetch stock market data from Finnhub
def fetch_stock_data():
    """Fetch stock data from Finnhub API."""
    stock_symbols = ["AAPL", "MSFT", "TSLA"]
    stock_data = {}

    for symbol in stock_symbols:
        url = f"http://finnhub.io/api/v1/quote?symbol={symbol}&token=put_your_ownfinnhubapikeyhere"
        response = requests.get(url).json()

        stock_data[symbol] = {
            "price": response.get("c", "N/A"),
            "change": response.get("d", "N/A"),
            "percent_change": response.get("dp", "N/A"),
            "timestamp": datetime.utcfromtimestamp(response.get("t", 0)).strftime('%m/%d/%Y %I:%M %p UTC')
        }

    return stock_data

# yummy live tiles
MSN_WEATHER_IMAGE_MAP = {
    "01d": "http://i.ibb.co/bgPy3r2D/9c.jpg",
    "01n": "https://i.ibb.co/xSPksFPh/31b.jpg",
    "02d": "https://i.ibb.co/1tL3M2p0/20250323_145949.jpg",
    "02n": "https://vortex.accuweather.com/adc2010/hostedpages/w8api/bg310x310/38.jpg",
    "03d": "https://i.ibb.co/d4BKRfcR/29b.jpg",
    "03n": "https://i.ibb.co/xSPksFPh/31b.jpg",
    "04d": "https://i.ibb.co/1tL3M2p0/20250323_145949.jpg",
    "04n": "http://i.ibb.co/4gX4rs2g/11.jpg",
    "09d": "https://i.ibb.co/FqD8cjBW/11b.jpg",
    "09n": "https://i.ibb.co/BVJ5vVr8/40.jpg",
    "10d": "http://vortex.accuweather.com/adc2010/hostedpages/w8api/bg310x310/14.jpg",
    "10n": "https://i.ibb.co/BVJ5vVr8/40.jpg",
    "11d": "https://i.ibb.co/53bTqvm/11b.jpg",
    "11n": "https://i.ibb.co/53bTqvm/11b.jpg",
    "50d": "https://i.ibb.co/KjcWRTjp/44.jpg",
    "50n": "https://i.ibb.co/KjwYgWVZ/20b.jpg",
    "13d": "https://i.ibb.co/pjpQZW3c/5-1.jpg",
    "13n": "https://i.ibb.co/67WkyCQ9/7.jpg",
}



# AccuWeather background image mapping
ACCUWEATHER_IMAGE_MAP = {
    "01d": "http://vortex.accuweather.com/adc2010/hostedpages/w8api/bg310x310/01_02.jpg",
    "01n": "http://vortex.accuweather.com/adc2010/hostedpages/w8api/bg310x310/33.jpg",
    "04n": "http://vortex.accuweather.com/adc2010/hostedpages/w8api/bg310x310/33.jpg",
    "04d": "http://vortext.accuweather.com/adc2010/hostedpages/w8api/bg310x130/03_04_05.jpg",
    "02d": "https://vortex.accuweather.com/adc2010/hostedpages/w8api/bg310x310/03_04_05.jpg",
    "02n": "http//vortex.accuweather.com/adc2010/hostedpages/w8api/bg310x310/38.jpg",
    "03d": "http://vortex.accuweather.com/adc2010/hostedpages/w8api/bg310x310/03_04_05.jpg",
    "03n": "http://vortex.accuweather.com/adc2010/hostedpages/w8api/bg310x310/30_31_32_34_35_36_37.jpg",
    "09d": "http://vortex.accuweather.com/adc2010/hostedpages/w8api/bg310x310/12_13_39_40.jpg",
    "09n": "http://vortex.accuweather.com/adc2010/hostedpages/w8api/bg310x310/24_25_26.jpg",
    "10d": "http://vortex.accuweather.com/adc2010/hostedpages/w8api/bg310x310/14.jpg",
    "10n": "http://vortex.accuweather.com/adc2010/hostedpages/w8api/bg310x310/18.jpg",
    "11d": "http://vortex.accuweather.com/adc2010/hostedpages/w8api/bg310x310/15_41_42.jpg",
    "11n": "http://vortex.accuweather.com/adc2010/hostedpages/w8api/bg310x310/24_25_26.JPG",
    "13d": "http://vortex.accuweather.com/adc2010/hostedpages/w8api/bg310x310/19_43.jpg",
    "13n": "http://vortex.accuweather.com/adc2010/hostedpages/w8api/bg310x310/29.jpg",
    "50d": "http://vortex.accuweather.com/adc2010/hostedpages/w8api/bg310x310/31.jpg",
    "50n": "http://vortex.accuweather.com/adc2010/hostedpages/w8api/bg310x310/11.jpg",
    
}

def fetch_weather_data():
    api_key = "put your own api key here"
    city = "your own city here,shortened name of your country"

    url_current = f"http://api.openweathermap.org/data/2.5/weather?q={city}&units=metric&appid={api_key}"
    response = requests.get(url_current)
    if not response.content:
        return None
    response.encoding = 'utf-8'
    
    try:
        data = response.json()
        if data.get("cod") != 200:
            return None
        
        temp = round(data["main"]["temp"])
        condition = data["weather"][0]["description"].capitalize()  # Fix missing "today_description"
        icon_code = data["weather"][0]["icon"]
        icon_url = f"http://openweathermap.org/img/wn/{icon_code}.png"
        wind_speed = round(data["wind"]["speed"] * 3.6)  # Convert from m/s to km/h
        humidity = data["main"]["humidity"]

        url_forecast = f"http://api.openweathermap.org/data/2.5/forecast?q={city}&units=metric&appid={api_key}"
        forecast_response = requests.get(url_forecast)
        forecast_data = forecast_response.json()

        if "list" not in forecast_data:
            return None
        
        tomorrow_data = forecast_data["list"][8]  
        tomorrow_high = round(tomorrow_data["main"]["temp_max"])
        tomorrow_low = round(tomorrow_data["main"]["temp_min"])
        tomorrow_description = tomorrow_data["weather"][0]["description"].capitalize()

        return {
            "current_temp": temp,
            "location": "Rio de Janeiro",
            "weather_icon_url": icon_url,
            "weather_condition": condition,
            "today_description": condition,  # ✅ Fix added
            "high_temp": round(data["main"]["temp_max"]),
            "low_temp": round(data["main"]["temp_min"]),
            "wind_speed": wind_speed,  
            "humidity": humidity,  
            "tomorrow_high": tomorrow_high,  
            "tomorrow_low": tomorrow_low,  
            "tomorrow_description": tomorrow_description,  
            "msn_weather_large": MSN_WEATHER_IMAGE_MAP.get(icon_code, "default_image_url.jpg"),
            "accuweather_large": ACCUWEATHER_IMAGE_MAP.get(icon_code, "http://vortex.accuweather.com/adc2010/hostedpages/w8api/bg310x310/default.jpg"),  # ✅ Fix
        }

    except Exception as e:
        return None


    
# Route to serve AccuWeather REPLACE THE LOCATION ID AND CITY PLACEHOLDER WITH THE ONE FOR YOUR CITY
# search up your city name + accuweather,the 7 digit numbers in the accuweather link is your location id,put it on these
# flask will not use these link urls if your city has its name with spaces,put a fallback location eg Florida to use it
@app.route("/w8api/livetile/forecast/1/en-us/your_locationidofyourcity/cityname/True/WorldSat/CSAM")
def serve_actual_weather():
    # Fetch weather data
    weather_data = fetch_weather_data()

    if not weather_data:
        return "Error fetching weather data", 500  # Return a 500 error if the data fetching fails

    # Load the XML template
    try:
        with open("c:/Tiles/weather_main.xml", "r", encoding="utf-8") as file:
            xml_content = file.read()
    except Exception as e:
        return f"Error reading XML file: {str(e)}", 500

    # Replace placeholders with actual weather data
    xml_content = xml_content.replace("{current_temp}", str(weather_data["current_temp"]))
    xml_content = xml_content.replace("{location}", weather_data["location"])
    xml_content = xml_content.replace("{weather_icon_url}", weather_data["weather_icon_url"])
    xml_content = xml_content.replace("{weather_condition}", weather_data["weather_condition"])
    xml_content = xml_content.replace("{high_temp}", str(weather_data["high_temp"]))
    xml_content = xml_content.replace("{low_temp}", str(weather_data["low_temp"]))
    xml_content = xml_content.replace("{today_description}", weather_data["today_description"])
    xml_content = xml_content.replace("{tomorrow_high}", str(weather_data["tomorrow_high"]))
    xml_content = xml_content.replace("{tomorrow_low}", str(weather_data["tomorrow_low"]))
    xml_content = xml_content.replace("{tomorrow_description}", weather_data["tomorrow_description"])
    xml_content = xml_content.replace("{accuweather_large}", weather_data["accuweather_large"])  # ✅ Fix

    return Response(xml_content, mimetype="application/xml")    

# Placeholder to add text for the 2nd AccuWeather live tile to replace {title}
text = [
    "Welcome to Retiled!",
    
]   

# Route for serving the Info tile replace location id and city name with your own
@app.route("/w8api/livetile/forecast/2/en-us/location_id/cityname/True/WorldSat/CSAM")
def serve_weather_secondary():
    # Load the XML template
    try:
        with open("c:/Tiles/weather_info.xml", "r", encoding="utf-8") as file:
            xml_content = file.read()
    except Exception as e:
        return f"Error reading XML file: {str(e)}", 500

    # Theres only one "gag" for {title}
    random_text = random.choice(text)
    xml_content = xml_content.replace("{title}", random_text)

    # Fetch weather data
    weather_data = fetch_weather_data()
    if not weather_data:
        return "Error fetching weather data", 500

    # Replace the placeholder with the actual AccuWeather background image
    xml_content = xml_content.replace("{accuweather_large}", weather_data["accuweather_large"])

    # Return the modified XML content with proper content type
    return Response(xml_content, mimetype="application/xml")

# same goes to this (Replace the location name inside weather_radar.xml with your own,today description is not affected)
@app.route("/w8api/livetile/forecast/3/en-us/2730001/Fluminense/True/WorldSat/CSAM")
def serve_weather_third():
     weather_data = fetch_weather_data()

     if not weather_data:
        return "Error fetching weather data", 500  # Return a 500 error if the data fetching fails
    
    # Load the XML template
     try:
        with open("c:/Tiles/weather_radar.xml", "r", encoding="utf-8") as file:
            xml_content = file.read()
     except Exception as e:
        return f"Error reading XML file: {str(e)}", 500
    

    # Replace it with your own city name inside the weather_radar.xml file
     xml_content = xml_content.replace("{today_description}", weather_data["today_description"])
    

    # Check if xml_content is properly populated
     if not xml_content:
         return "Error generating XML content", 500

    # Return the modified XML content with proper response and content type
     return Response(xml_content, mimetype="application/xml")

# Location changing not really needed for this one. (check if you have the location set on the placeholders (replace the placeholder on the city thing with yours)
@app.route("/appex/DesktopTile/LiveTileV2")
def serve_msn_weather():
    weather_data = fetch_weather_data()
    if not weather_data:
        return "Error fetching weather data", 500
    try:
        with open("c:/Tiles/msn_weather.xml", "r", encoding="utf-8") as file:
            xml_content = file.read()
    except Exception as e:
        return f"Error reading XML file: {str(e)}", 500
    xml_content = xml_content.replace("{current_temp}", str(weather_data["current_temp"]))
    xml_content = xml_content.replace("{location}", weather_data["location"])
    xml_content = xml_content.replace("{weather_icon_url}", weather_data["weather_icon_url"])
    xml_content = xml_content.replace("{weather_condition}", weather_data["weather_condition"])
    xml_content = xml_content.replace("{high_temp}", str(weather_data["high_temp"]))
    xml_content = xml_content.replace("{low_temp}", str(weather_data["low_temp"]))
    xml_content = xml_content.replace("{msn_weather_large}", weather_data["msn_weather_large"])
    xml_content = xml_content.replace("{today_description}", weather_data["today_description"])
    xml_content = xml_content.replace("{tomorrow_high}", str(weather_data["tomorrow_high"]))
    xml_content = xml_content.replace("{tomorrow_low}", str(weather_data["tomorrow_low"]))
    xml_content = xml_content.replace("{tomorrow_description}", weather_data["tomorrow_description"]) 


    return Response(xml_content, mimetype="application/xml")


@app.route("/Market.svc/AppTileV2")
def serve_financedata():
    """Serve the finance tile with updated stock data."""
    # Fetch stock data from Finnhub
    stock_data = fetch_stock_data()

    # Read the XML template (adjust the path to the XML file)
    try:
        with open("AppTileV2.xml", "r", encoding="utf-8-sig") as file:
            xml_content = file.read()
    except FileNotFoundError:
        return "Error: XML template not found", 404



    # Replace placeholders in the XML with stock data
    xml_content = xml_content.replace("{AAPL_PRICE}", f"{stock_data['AAPL']['price']}")
    xml_content = xml_content.replace("{AAPL_CHANGE}", f"{stock_data['AAPL']['change']} ({stock_data['AAPL']['percent_change']}%)")
    xml_content = xml_content.replace("{MSFT_PRICE}", f"{stock_data['MSFT']['price']}")
    xml_content = xml_content.replace("{MSFT_CHANGE}", f"{stock_data['MSFT']['change']} ({stock_data['MSFT']['percent_change']}%)")
    xml_content = xml_content.replace("{TSLA_PRICE}", f"{stock_data['TSLA']['price']}")
    xml_content = xml_content.replace("{TSLA_CHANGE}", f"{stock_data['TSLA']['change']} ({stock_data['TSLA']['percent_change']}%)")
    xml_content = xml_content.replace("{LAST_UPDATE}", stock_data["AAPL"]["timestamp"])



    # Return the updated XML with MIME type
    return Response(xml_content, mimetype="application/xml; charset=utf-8")
   



# Route to serve News tile XML files
@app.route("/cgtile/v1/EN-US/News/Today.xml")
def serve_news_today():
    return serve_tile_for_category("news", "Today.xml")

@app.route("/cgtile/v1/EN-US/News/today/2.xml")
def serve_news_2():
    return serve_tile_for_category("news", "2.xml")

@app.route("/cgtile/v1/EN-US/News/today/3.xml")
def serve_news_3():
    return serve_tile_for_category("news", "3.xml")

@app.route("/cgtile/v1/EN-US/News/today/4.xml")
def serve_news_4():
    return serve_tile_for_category("news", "4.xml")

# Route to serve Finance tile XML file
@app.route("/cgtile/v1/en-us/Finance/Today.xml")
def serve_finance_today():
    return serve_tile_for_category("finance", "Today.xml")

# Route to serve Sports tile XML file
@app.route("/cgtile/v1/en-US/Sports/Today.xml")
def serve_sports_today():
    return serve_tile_for_category("sports", "Today.xml")

# Route to serve HealthAndFitness tile XML file
@app.route("/cgtile/v1/en-us/HealthAndFitness/Home.xml")
def serve_health_and_fitness():
    return serve_tile_for_category("health", "Home.xml")
# Route to serve Games tile XML file
@app.route("/en-us/x8/feeds/1.1/Tile-Games")
def serve_games():
    return serve_tile_for_category("games", "Tile-Games.xml")

# Route to serve bing travel
@app.route("/api/livetile.xml")
def serve_travel(): 
    return serve_tile_for_category("travel", "livetile.xml")

# Route to serve Finance tile XML file
@app.route("/en-US/video/feeds/1.2/videolivetile")
def serve_video():
    return serve_tile_for_category("video", "videolivetile.xml")
             

@app.route("/HnFService.svc/GetLiveTileMetaData") 
def serve_fitness():
    return serve_tile_for_category("fitness", "GetLiveTileMetaData.xml")

@app.route("/api/feed/") 
def serve_food():
    return serve_tile_for_category("food", "feed.xml")


def serve_tile_for_category(category, file_name):
    xml_file_path = os.path.join(TILE_XML_FOLDER, file_name)
    if os.path.exists(xml_file_path):
        with open(xml_file_path, "r", encoding="utf-8") as xml_file:
            xml_content = xml_file.read()
            # Fetch RSS data for categories

            if category == "news":
                articles = fetch_rss_data("news")
                if articles:
                    xml_content = xml_content.replace("{article_text}", articles[0]["title"])
                    xml_content = xml_content.replace("{article_text2}", articles[1]["title"] if len(articles) > 1 else "")
                    xml_content = xml_content.replace("{article_text3}", articles[2]["title"] if len(articles) > 2 else "")
                    xml_content = xml_content.replace("{article_text4}", articles[3]["title"] if len(articles) > 2 else "")
                    xml_content = xml_content.replace("{article_text5}", articles[4]["title"] if len(articles) > 2 else "")
                    xml_content = xml_content.replace("{article_text6}", articles[5]["title"] if len(articles) > 2 else "")
                    xml_content = xml_content.replace("{article_text7}", articles[6]["title"] if len(articles) > 2 else "")
                    xml_content = xml_content.replace("{article_text8}", articles[7]["title"] if len(articles) > 2 else "")
                    xml_content = xml_content.replace("{article_text9}", articles[8]["title"] if len(articles) > 2 else "")
                    xml_content = xml_content.replace("{article_text10}", articles[9]["title"] if len(articles) > 2 else "")
                    xml_content = xml_content.replace("{img_url}", articles[0]["image"] if articles[0]["image"] else "")

            elif category == "sports":
                articles = fetch_rss_data("sports")
                if articles:
                    xml_content = xml_content.replace("{article_text}", articles[0]["title"])
                    xml_content = xml_content.replace("{article_2}", articles[1]["title"] if len(articles) > 1 else "")
                    xml_content = xml_content.replace("{article_3}", articles[2]["title"] if len(articles) > 2 else "")
                    xml_content = xml_content.replace("{img_url}", articles[0]["image"] if articles[0]["image"] else "")

            elif category == "health":
                articles = fetch_rss_data("health")
                if articles:
                    xml_content = xml_content.replace("{text}", articles[0]["title"])
                    xml_content = xml_content.replace("{article_2}", articles[1]["title"] if len(articles) > 1 else "")
                    xml_content = xml_content.replace("{article_3}", articles[2]["title"] if len(articles) > 2 else "")
                    xml_content = xml_content.replace("{health_img}", articles[0]["image"] if articles[0]["image"] else "")

            elif category == "food":
                articles = fetch_rss_data("food")
                if articles:
                    xml_content = xml_content.replace("{food_text}", articles[0]["title"])
                    xml_content = xml_content.replace("{article_2}", articles[1]["title"] if len(articles) > 1 else "")
                    xml_content = xml_content.replace("{article_3}", articles[2]["title"] if len(articles) > 2 else "")
                    xml_content = xml_content.replace("{img_url}", articles[0]["image"] if articles[0]["image"] else "")

            elif category == "travel":
                articles = fetch_rss_data("travel")
                if articles:
                    xml_content = xml_content.replace("{article_text}", articles[0]["title"])
                    xml_content = xml_content.replace("{article_2}", articles[1]["title"] if len(articles) > 1 else "")
                    xml_content = xml_content.replace("{article_3}", articles[2]["title"] if len(articles) > 2 else "")
                    xml_content = xml_content.replace("{img_url}", articles[0]["image"] if articles[0]["image"] else "")

            elif category == "fitness":
                articles = fetch_rss_data("fitness")
                if articles:
                    xml_content = xml_content.replace("{headline}", articles[0]["title"])
                    xml_content = xml_content.replace("{article_2}", articles[1]["title"] if len(articles) > 1 else "")
                    xml_content = xml_content.replace("{article_3}", articles[2]["title"] if len(articles) > 2 else "")
                    xml_content = xml_content.replace("{img_url}", articles[0]["image"] if articles[0]["image"] else "")

            elif category == "games":
                articles = fetch_rss_data("games")
                if articles:
                    xml_content = xml_content.replace("{game_title}", articles[0]["title"])
                    xml_content = xml_content.replace("{article_2}", articles[1]["title"] if len(articles) > 1 else "")
                    xml_content = xml_content.replace("{article_3}", articles[2]["title"] if len(articles) > 2 else "")
                    xml_content = xml_content.replace("{game_img}", articles[0]["image"] if articles[0]["image"] else "")

            elif category == "video":
                articles = fetch_rss_data("video")
                if articles:
                    xml_content = xml_content.replace("{movie_name}", articles[0]["title"])
                    xml_content = xml_content.replace("{article_2}", articles[1]["title"] if len(articles) > 1 else "")
                    xml_content = xml_content.replace("{article_3}", articles[2]["title"] if len(articles) > 2 else "")
                    xml_content = xml_content.replace("{img_url}", articles[0]["image"] if articles[0]["image"] else "")


            elif category == "finance":
                articles = fetch_rss_data("finance")
                if articles:
                    xml_content = xml_content.replace("{article_text}", articles[0]["title"])
                    xml_content = xml_content.replace("{article_2}", articles[1]["title"] if len(articles) > 1 else "")
                    xml_content = xml_content.replace("{article_3}", articles[2]["title"] if len(articles) > 2 else "")
                    xml_content = xml_content.replace("{img_url}", articles[0]["image"] if articles[0]["image"] else "")

        return Response(xml_content, mimetype="application/xml")

    return "Tile not found", 404

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=80, debug=True)
